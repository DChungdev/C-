﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai3
{
    internal class Car:Vehicles
    {
        private int seats;
        public int Seats { get => seats; set => seats = value; }

        public Car():base() { }
        public Car(string id, string maker, string model, int year, string type, int seats):base(id,maker,model,year,type)
        {
            this.Seats = seats;
        }
        public override string NienHanSuDung()
        {
            if(Seats >= 9)
            {
                return "30";
            }
            return "Khong ap dung";
        }
        public override string ToString()
        {
            return base.ToString() + String.Format("{0,4}",Seats);
        }
    }
}
