﻿using System.Collections;
using System.Diagnostics;

namespace Bai3
{
    internal class Program
    {
        static List<Vehicles> dsX = new List<Vehicles>();
        static void Main(string[] args)
        {
            try
            {
                int c = 0;
                do
                {
                    Console.WriteLine("===Menu===");
                    Console.WriteLine("1. Nhap du lieu");
                    Console.WriteLine("2. Hien thi du lieu");
                    Console.WriteLine("3. Tim kiem theo id");
                    Console.WriteLine("4. Tim kiem theo maker");
                    Console.WriteLine("5. Sap xep theo price");
                    Console.WriteLine("6. Sap xep theo year");
                    Console.WriteLine("7. Ket thuc");
                    c = int.Parse(Console.ReadLine());
                    switch (c)
                    {
                        case 1:
                            Input();
                            break;
                        case 2:
                            Console.WriteLine("{0,5}{1,15}{2,15}{3,5}{4,10}{5,15}{6,10}","ID","Maker","Model","Year","Type","HSD","Load/Seat");
                            Output(); 
                            break;
                        case 3:
                            string id;
                            Console.Write("Nhap id can tim: ");
                            id = Console.ReadLine();
                            SearchByID(id);
                            break;
                        case 4:
                            string maker;
                            Console.Write("Nhap maker can tim: ");
                            maker = Console.ReadLine();
                            SearchByMaker(maker);
                            break;
                        case 6:
                            Console.WriteLine("Ds truoc khi sap xep");
                            Output();
                            dsX.Sort(new SortByYear());
                            Console.WriteLine("Ds truoc sau khi sap xep");
                            Output();
                            break;
                        default: Console.WriteLine("Ban chon khong dung"); break;
                    }
                } while (c != 7);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchByMaker(string? maker)
        {
            int count = 0;
            foreach (var vh in dsX)
            {
                if (String.Compare(maker, vh.Maker, true) == 0)
                {                  
                    Console.WriteLine("{0,5}{1,15}{2,15}{3,5}{4,10}{5,15}{6,10}", "ID", "Maker", "Model", "Year", "Type", "HSD", "Load/Seat");
                    Console.WriteLine(vh);
                    count++;
                }
            }
            if (count == 0)
            {
                Console.WriteLine("Khong tim thay maker " + maker);
            }
        }

        private static void SearchByID(string? id)
        {
            foreach(var vh in dsX)
            {
                if (String.Compare(id, vh.Id, true) == 0)
                {
                    Console.WriteLine("Tim thay ma " + id);
                    Console.WriteLine("{0,5}{1,15}{2,15}{3,5}{4,10}{5,15}{6,10}", "ID", "Maker", "Model", "Year", "Type", "HSD", "Load/Seat");
                    Console.WriteLine(vh);
                    return;
                }        
            }
            Console.WriteLine("Khong tim thay ma " + id);
        }

        private static void Output()
        {
            foreach(var v in dsX) 
            {
                Console.WriteLine(v);
            }
        }

        private static void Input()
        {
            string id, maker, model, type;
            int year;
            Console.WriteLine("Nhap vao thong tin xe:");
            Console.Write("ID: "); id = Console.ReadLine();
            Console.Write("Maker: "); maker = Console.ReadLine();
            Console.Write("Model: "); model = Console.ReadLine();
            Console.Write("Year: "); year = int.Parse(Console.ReadLine());
            Console.Write("Type: "); type = Console.ReadLine();
            if(String.Compare(type, "xe tai", true) == 0)
            {               
                int load;
                Console.Write("Load: "); load = int.Parse(Console.ReadLine());
                Truck truck = new Truck(id,maker,model,year,type,load);
                if(Check(truck))
                {
                    dsX.Add(truck);
                }
                else
                {
                    Console.WriteLine("Id {0} da ton tai!", id);
                }
            }
            else
            {
                int seats;
                Console.Write("Seats: "); seats = int.Parse(Console.ReadLine());
                Car car = new Car(id, maker, model, year, type, seats);
                if (Check(car))
                {
                    dsX.Add(car);
                }
                else
                {
                    Console.WriteLine("Id {0} da ton tai!", id);
                }
            }
        }
        private static bool Check(Vehicles v)
        {
            foreach(var a in dsX)
            {
                if (v.Equals(a))
                {
                    return false;
                }
            }
            return true;
        }

    }
    public class SortByYear : IComparer<Vehicles>
    {

        int IComparer<Vehicles>.Compare(Vehicles? x, Vehicles? y)
        {
            Vehicles v1 = (Vehicles)x;
            Vehicles v2 = (Vehicles)y;
            if(v1.Year < v2.Year)
            {
                return 1;
            }
            else if (v1.Year > v2.Year)
            {
                return -1;
            }
            return 0;
        }
    }
}