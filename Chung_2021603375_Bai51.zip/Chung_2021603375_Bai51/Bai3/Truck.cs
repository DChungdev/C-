﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai3
{
    internal class Truck:Vehicles
    {
        private int load;
        public int Load { get => load; set => load = value; }
        public Truck():base() { }
        public Truck(string id, string maker, string model, int year, string type, int load) : base(id, maker, model, year, type)
        {
            Load = load;
        }
        public override string ToString()
        {
            return base.ToString() + String.Format("{0,4}", Load);
        }
    }
}
