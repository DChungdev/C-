﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai3
{
    internal class Vehicles : Ivehicle
    {
        private string id;
        private string maker;
        private string model;
        private int year;
        private string type;
        public string Id { get => id; set => id = value; }
        public string Maker { get => maker; set => maker = value; }
        public string Model { get => model; set => model = value; }
        public int Year { get => year; set => year = value; }
        public string Type { get => type; set => type = value; }

        public Vehicles() { }
        public Vehicles(string id, string maker, string model, int year, string type)
        {
            Id = id;
            Maker = maker;
            Model = model;
            Year = year;
            Type = type;
        }
        public virtual string NienHanSuDung()
        {
            if(String.Compare(Type,"xe tai", true) == 0)
            {
                return "20";
            }
            return "30";
        }
        public override bool Equals(object? obj)
        {
            Vehicles vh = (Vehicles)obj;
            return Id.Equals(vh.Id);
        }
        public override string ToString()
        {
            return String.Format("{0,5}{1,15}{2,15}{3,5}{4,10}{5,15}",Id,Maker,Model,Year,Type,NienHanSuDung());
        }

    }
}
