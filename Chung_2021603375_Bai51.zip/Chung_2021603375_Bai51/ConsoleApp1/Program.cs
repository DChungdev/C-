﻿using Bai1;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            try
            {
                Console.WriteLine("Nhap vao a,b,c:");
                a = int.Parse(Console.ReadLine());
                b = int.Parse(Console.ReadLine());
                c = int.Parse(Console.ReadLine());
                if(a == 0)
                {
                    Console.WriteLine("a phai khac 0!");
                }
                else
                {
                    GiaiPhuongTrinhBac2 g = new GiaiPhuongTrinhBac2(a, b, c);
                    g.Giai();
                }
          
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}