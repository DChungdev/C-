﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai1
{
    internal class GiaiPhuongTrinhBac2
    {
        private int a;
        private int b;
        private int c;
        public int A { get => a; set => a = value; }
        public int B { get => b; set => b = value; }
        public int C { get => c; set => c = value; }
        public GiaiPhuongTrinhBac2() { }
        public GiaiPhuongTrinhBac2(int A, int B, int C)
        {
            this.A = A;
            this.B = B;
            this.C = C;
        }
        public void Giai()
        {
            double delta = B * B - 4 * A * C;
            if(delta > 0)
            {
                Console.WriteLine("Phuong trinh co 2 nghiem phan biet");
                double x1 = (-B + Math.Sqrt(delta))/(2 * A);
                double x2 = (-B - Math.Sqrt(delta)) / (2 * A);
                Console.WriteLine("x1 = " + x1);
                Console.WriteLine("x2 = " + x2);
            }
            else if(delta == 0)
            {
                Console.WriteLine("Phuong trinh co nghiem kep");
                double x = -B / (2 * A);
                Console.WriteLine("x1 = x2 = " + x);
            }
            else
            {
                Console.WriteLine("Phuong trinh vo nghiem");
            }
        }
    }
}
