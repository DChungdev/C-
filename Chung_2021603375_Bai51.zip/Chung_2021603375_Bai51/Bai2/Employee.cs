﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    internal class Employee
    {
        private string id;
        private string name;
        private int age;
        private int workingdays;
        private double salary
        {
            get
            {
                return workingdays * PRICE;
            }
        }
        const int PRICE = 50;
        public string Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public int Age { get => age; set => age = value; }
        public int Workingdays { get => workingdays; set => workingdays = value; }
        public double Salary()
        { 
            return salary;        
        }
        public Employee(string id, string name, int age, int workingdays)
        {
            Id = id;
            Name = name;
            Age = age;
            Workingdays = workingdays;
        }
    }
}
