﻿namespace Bai2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee a = new Employee("NV1", "Chung", 20, 20);
            Console.WriteLine("Ma: " + a.Id);
            Console.WriteLine("Ten: "+ a.Name);
            Console.WriteLine("Tuoi: " + a.Age);
            Console.WriteLine("Working day: " + a.Workingdays);
            Console.WriteLine("Salary: " + a.Salary());
        }
    }
}